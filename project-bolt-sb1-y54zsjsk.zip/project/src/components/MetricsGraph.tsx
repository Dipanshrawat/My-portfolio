import React from 'react';
import { motion } from 'framer-motion';
import { BarChart } from 'lucide-react';

interface MetricsGraphProps {
  metrics: { label: string; value: number }[];
}

export function MetricsGraph({ metrics }: MetricsGraphProps) {
  const maxValue = Math.max(...metrics.map(m => m.value));

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-lg bg-background/80 p-4 backdrop-blur-sm"
    >
      <div className="flex items-center gap-2 mb-4">
        <BarChart className="w-4 h-4 text-primary" />
        <span className="text-xs text-gray-400">Performance Metrics</span>
      </div>
      <div className="space-y-3">
        {metrics.map((metric, index) => (
          <div key={index} className="space-y-1">
            <div className="flex justify-between text-xs">
              <span className="text-gray-400">{metric.label}</span>
              <span className="text-primary">{metric.value}%</span>
            </div>
            <motion.div
              className="h-2 bg-secondary rounded-full overflow-hidden"
              initial={{ width: 0 }}
              animate={{ width: '100%' }}
              transition={{ delay: index * 0.1 }}
            >
              <motion.div
                className="h-full bg-primary"
                initial={{ width: 0 }}
                animate={{ width: `${(metric.value / maxValue) * 100}%` }}
                transition={{ duration: 1, delay: index * 0.1 }}
              />
            </motion.div>
          </div>
        ))}
      </div>
    </motion.div>
  );
}