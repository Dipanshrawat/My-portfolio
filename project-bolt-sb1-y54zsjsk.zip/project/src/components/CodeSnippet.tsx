import React from 'react';
import { motion } from 'framer-motion';
import { Code2 } from 'lucide-react';

interface CodeSnippetProps {
  code: string;
}

export function CodeSnippet({ code }: CodeSnippetProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-lg bg-background/80 p-4 backdrop-blur-sm"
    >
      <div className="flex items-center gap-2 mb-2">
        <Code2 className="w-4 h-4 text-primary" />
        <span className="text-xs text-gray-400">Code Sample</span>
      </div>
      <pre className="text-xs overflow-x-auto">
        <code className="text-primary">{code}</code>
      </pre>
    </motion.div>
  );
}