import React from 'react';
import { motion } from 'framer-motion';
import { Code2, Terminal, Cpu, Wifi } from 'lucide-react';

export function ComputerSetup() {
  return (
    <section className="py-20 px-4 relative">
      <div className="max-w-6xl mx-auto">
        <div className="relative">
          {/* Computer Monitor */}
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="bg-secondary p-8 rounded-lg shadow-2xl mb-4"
          >
            <div className="bg-background p-6 rounded-md">
              <div className="flex items-center gap-2 mb-4">
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                  className="w-3 h-3 rounded-full bg-red-500"
                />
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ repeat: Infinity, duration: 2, delay: 0.2 }}
                  className="w-3 h-3 rounded-full bg-yellow-500"
                />
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ repeat: Infinity, duration: 2, delay: 0.4 }}
                  className="w-3 h-3 rounded-full bg-green-500"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  className="bg-secondary/50 p-4 rounded-md"
                >
                  <Terminal className="w-6 h-6 text-primary mb-2" />
                  <code className="text-sm text-primary">
                    $ java -version<br />
                    $ dotnet --info
                  </code>
                </motion.div>
                
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  className="bg-secondary/50 p-4 rounded-md"
                >
                  <Code2 className="w-6 h-6 text-primary mb-2" />
                  <code className="text-sm text-primary">
                    &lt;middleware&gt;<br />
                    &nbsp;&nbsp;expert<br />
                    &lt;/middleware&gt;
                  </code>
                </motion.div>
              </div>
            </div>
          </motion.div>

          {/* Computer Base */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="bg-secondary/80 h-4 rounded-lg mx-auto w-1/3"
          />

          {/* Status Indicators */}
          <div className="flex justify-center gap-8 mt-8">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
              className="flex items-center gap-2"
            >
              <Cpu className="text-primary animate-pulse" />
              <span className="text-sm">System Active</span>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8 }}
              className="flex items-center gap-2"
            >
              <Wifi className="text-primary animate-pulse" />
              <span className="text-sm">Connected</span>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}