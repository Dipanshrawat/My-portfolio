import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Terminal } from 'lucide-react';

interface TerminalWindowProps {
  commands: string[];
}

export function TerminalWindow({ commands }: TerminalWindowProps) {
  const [visibleCommands, setVisibleCommands] = useState<string[]>([]);

  useEffect(() => {
    commands.forEach((cmd, index) => {
      setTimeout(() => {
        setVisibleCommands(prev => [...prev, cmd]);
      }, index * 1000);
    });
  }, [commands]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-lg bg-background/80 p-4 backdrop-blur-sm"
    >
      <div className="flex items-center gap-2 mb-2">
        <Terminal className="w-4 h-4 text-primary" />
        <span className="text-xs text-gray-400">Terminal</span>
      </div>
      <div className="font-mono text-xs">
        {visibleCommands.map((cmd, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="mb-1"
          >
            <span className="text-primary">$ </span>
            <span className="text-gray-300">{cmd}</span>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}