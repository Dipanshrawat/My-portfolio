import React from 'react';
import { motion } from 'framer-motion';
import { Server, Cloud, Database, Cpu } from 'lucide-react';
import { TechCard } from './TechCard';
import { Footer } from './Footer';

export function Experience() {
  const experiences = [
    {
      icon: <Cpu />,
      title: "DevOps & Cloud Architecture",
      description: "AWS, Azure, Kubernetes, CI/CD, Infrastructure as Code",
      blog: `As a DevOps Engineer at Cognizant, I architected and implemented enterprise-scale cloud infrastructure using AWS and Azure. I led the migration of a mission-critical application serving 100,000+ users from on-premise to a multi-cloud architecture, achieving 99.99% uptime and 40% cost reduction.

I designed and implemented a fully automated CI/CD pipeline using Jenkins, Docker, and Kubernetes, reducing deployment time from hours to minutes. The pipeline included automated testing, security scanning, and blue-green deployments, resulting in zero-downtime updates.

Key achievements included implementing Infrastructure as Code using Terraform and CloudFormation, managing a Kubernetes cluster with 200+ microservices, and creating custom monitoring solutions using Prometheus and Grafana. I also developed automated disaster recovery procedures that reduced RTO from 4 hours to 15 minutes.`,
      codeSnippet: `# Kubernetes Deployment Configuration
apiVersion: apps/v1
kind: Deployment
metadata:
  name: microservice-app
  namespace: production
spec:
  replicas: 3
  strategy:
    type: RollingUpdate
  template:
    spec:
      containers:
      - name: app
        image: app:latest
        resources:
          limits:
            cpu: "1"
            memory: "1Gi"
        readinessProbe:
          httpGet:
            path: /health
            port: 8080`,
      terminalCommands: [
        "kubectl apply -f deployment.yaml",
        "terraform plan -out=tfplan",
        "aws eks update-kubeconfig --region us-west-2",
        "az aks get-credentials --resource-group myRG"
      ],
      metrics: [
        { label: "Uptime", value: 99.99 },
        { label: "Cost Reduction", value: 40 },
        { label: "Deployment Speed", value: 95 },
        { label: "Infrastructure Coverage", value: 100 }
      ]
    },
    {
      icon: <Server />,
      title: "Middleware Expertise",
      description: "Apache, Tomcat, JBoss, WebSphere, WebLogic server management and optimization",
      blog: `During my tenure at Cognizant as a Middleware Engineer, I spearheaded the transformation of a legacy WebSphere infrastructure supporting a Fortune 500 financial services client. In Q3 2023, I orchestrated the migration of 50+ mission-critical applications to Apache Tomcat, resulting in a 40% reduction in licensing costs and a 25% improvement in application response times.

Key achievements included implementing automated deployment pipelines that reduced deployment times from hours to minutes, and designing a high-availability clustering solution that achieved 99.99% uptime. I also mentored a team of 3 junior engineers, introducing them to container orchestration and microservices architecture.

The project's success led to its adoption as a blueprint for similar transformations across other business units.`,
      codeSnippet: `// High Availability Cluster Configuration
@Configuration
public class HAClusterConfig {
    @Bean
    public ClusterManager clusterManager() {
        return new TomcatClusterManager()
            .setReplicationStrategy(SYNC)
            .setFailoverEnabled(true)
            .setHealthCheckInterval(5000);
    }
}`,
      terminalCommands: [
        "systemctl status tomcat",
        "docker-compose up -d ha-cluster",
        "kubectl apply -f cluster-config.yaml",
        "./monitor-health.sh --cluster prod"
      ],
      metrics: [
        { label: "Uptime", value: 99.99 },
        { label: "Response Time", value: 75 },
        { label: "Cost Reduction", value: 40 },
        { label: "Deployment Speed", value: 95 }
      ]
    },
    {
      icon: <Cloud />,
      title: "Cloud Solutions",
      description: "AWS & Azure Cloud Architecture, Certified Solutions Developer",
      blog: `Leading cloud transformation initiatives at Cognizant exposed me to complex AWS and Azure architectures. I hold certifications in Azure (AZ-204 Azure Solutions Developer) and Google Cloud (Associate), validating my expertise in cloud-native development and architecture.

I architected and implemented a serverless solution for a major retail client, leveraging AWS Lambda, API Gateway, and DynamoDB. This modernization effort replaced an aging on-premise system, resulting in a 60% reduction in operational costs.

I designed and implemented a multi-region disaster recovery solution using AWS Route 53, S3 cross-region replication, and Aurora Global Database. This architecture ensured business continuity with an RPO of < 1 second and RTO of < 5 minutes. The solution successfully handled a failover during a regional outage, maintaining uninterrupted service for over 2 million users.`,
      codeSnippet: `// Azure Function with Cosmos DB Integration
module.exports = async function (context, req) {
    const { CosmosClient } = require("@azure/cosmos");
    const client = new CosmosClient(process.env.COSMOS_CONNECTION);
    
    try {
        const database = client.database("retail");
        const container = database.container("orders");
        
        const { resource: createdItem } = await container
            .items.create({
                id: req.body.orderId,
                category: "Electronics",
                status: "Pending"
            });
            
        context.res = {
            status: 201,
            body: createdItem
        };
    } catch (error) {
        context.res = {
            status: 500,
            body: error.message
        };
    }
};`,
      terminalCommands: [
        "az functionapp deploy",
        "aws lambda update-function-code",
        "terraform apply -auto-approve",
        "gcloud functions deploy"
      ],
      metrics: [
        { label: "Cost Savings", value: 60 },
        { label: "System Reliability", value: 99.95 },
        { label: "Response Time", value: 85 },
        { label: "Recovery Time", value: 98 }
      ]
    }
  ];

  return (
    <section className="py-20 px-4 bg-background/95">
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="max-w-6xl mx-auto"
      >
        <h2 className="text-3xl font-bold mb-12 text-center">Technical Expertise</h2>
        <div className="grid grid-cols-1 gap-8">
          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ delay: index * 0.2 }}
            >
              <TechCard {...exp} />
            </motion.div>
          ))}
        </div>
      </motion.div>
      <Footer />
    </section>
  );
}