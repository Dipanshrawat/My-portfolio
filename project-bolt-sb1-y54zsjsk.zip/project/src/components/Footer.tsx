import React from 'react';
import { motion } from 'framer-motion';
import { Code2, Github, Linkedin, Mail, Terminal, Award } from 'lucide-react';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="mt-20 border-t border-primary/20">
      <div className="max-w-6xl mx-auto py-12 px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <motion.div 
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              className="flex items-center gap-2 mb-4"
            >
              <Terminal className="w-6 h-6 text-primary" />
              <span className="font-bold text-lg">Tech Portfolio</span>
            </motion.div>
            <div className="space-y-2">
              <p className="text-sm text-gray-400">
                DevOps Engineer & Cloud Architect
              </p>
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-primary" />
                <span className="text-xs text-gray-400">Azure & Google Cloud Certified</span>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-4 flex items-center gap-2">
              <Code2 className="w-4 h-4 text-primary" />
              Tech Stack
            </h4>
            <div className="grid grid-cols-2 gap-2 text-sm text-gray-400">
              <span>AWS & Azure</span>
              <span>Kubernetes</span>
              <span>Jenkins</span>
              <span>Terraform</span>
              <span>Docker</span>
              <span>Bash</span>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Connect</h4>
            <div className="flex gap-4">
              <a
                href="https://github.com/Dipanshrawat?tab=repositories"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-primary transition-colors"
              >
                <Github className="w-5 h-5" />
              </a>
              <a
                href="https://www.linkedin.com/in/dipansh-rawat-b493a9183"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-primary transition-colors"
              >
                <Linkedin className="w-5 h-5" />
              </a>
              <a
                href="mailto:28dipanshrawat@gmail.com"
                className="text-gray-400 hover:text-primary transition-colors"
              >
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-primary/20 text-center text-sm text-gray-400">
          <p>© {currentYear} Tech Portfolio. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}