import React from 'react';
import { motion } from 'framer-motion';
import { Terminal, Github, Linkedin, Award } from 'lucide-react';

export function Hero() {
  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/20 via-background to-background" />
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="relative z-10 text-center px-4"
      >
        <Terminal className="w-16 h-16 mx-auto mb-8 text-primary animate-float" />
        <h1 className="text-4xl md:text-6xl font-bold mb-6">
          Dipansh: DevOps & Cloud Solutions Architect
        </h1>
        <p className="text-xl text-gray-400 mb-4 max-w-2xl mx-auto">
          Specializing in Cloud Architecture, DevOps, and Enterprise Middleware Solutions
        </p>
        <div className="flex items-center justify-center gap-4 mb-8">
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="flex items-center gap-2 bg-secondary/50 px-4 py-2 rounded-full"
          >
            <Award className="w-4 h-4 text-primary" />
            <span className="text-sm">AZ-204 Certified</span>
          </motion.div>
          <motion.div
            whileHover={{ scale: 1.05 }}
            className="flex items-center gap-2 bg-secondary/50 px-4 py-2 rounded-full"
          >
            <Award className="w-4 h-4 text-primary" />
            <span className="text-sm">Google Cloud Associate</span>
          </motion.div>
        </div>
        <div className="flex gap-4 justify-center">
          <a 
            href="https://github.com/Dipanshrawat?tab=repositories" 
            className="p-2 rounded-full bg-secondary hover:bg-secondary/80 transition-colors"
            target="_blank"
            rel="noopener noreferrer"
          >
            <Github className="w-6 h-6" />
          </a>
          <a 
            href="https://www.linkedin.com/in/dipansh-rawat-b493a9183" 
            className="p-2 rounded-full bg-secondary hover:bg-secondary/80 transition-colors"
            target="_blank"
            rel="noopener noreferrer"
          >
            <Linkedin className="w-6 h-6" />
          </a>
        </div>
      </motion.div>
    </div>
  );
}