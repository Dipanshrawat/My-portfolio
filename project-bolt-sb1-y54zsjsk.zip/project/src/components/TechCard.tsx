import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ChevronUp, Terminal, Code2 } from 'lucide-react';
import { CodeSnippet } from './CodeSnippet';
import { TerminalWindow } from './TerminalWindow';
import { MetricsGraph } from './MetricsGraph';

interface TechCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  blog: string;
  codeSnippet?: string;
  terminalCommands?: string[];
  metrics?: { label: string; value: number }[];
}

export function TechCard({ 
  icon, 
  title, 
  description, 
  blog,
  codeSnippet,
  terminalCommands,
  metrics 
}: TechCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <motion.div
      layout
      className="p-6 rounded-lg bg-secondary/50 backdrop-blur-sm overflow-hidden border border-primary/20"
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.2 }}
    >
      <motion.div layout className="flex items-start justify-between">
        <div className="flex-1">
          <motion.div 
            className="w-12 h-12 mb-4 text-primary"
            whileHover={{ rotate: 360 }}
            transition={{ duration: 0.5 }}
          >
            {icon}
          </motion.div>
          <h3 className="text-lg font-semibold mb-2">{title}</h3>
          <p className="text-sm text-gray-400 mb-4">{description}</p>
        </div>
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="p-2 hover:bg-primary/20 rounded-full transition-colors"
        >
          {isExpanded ? <ChevronUp /> : <ChevronDown />}
        </button>
      </motion.div>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="mt-4 pt-4 border-t border-primary/20"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="prose prose-invert max-w-none">
                {blog.split('\n\n').map((paragraph, index) => (
                  <p key={index} className="text-sm leading-relaxed mb-4 text-gray-300">
                    {paragraph}
                  </p>
                ))}
              </div>
              <div className="space-y-6">
                {codeSnippet && <CodeSnippet code={codeSnippet} />}
                {terminalCommands && <TerminalWindow commands={terminalCommands} />}
                {metrics && <MetricsGraph metrics={metrics} />}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}