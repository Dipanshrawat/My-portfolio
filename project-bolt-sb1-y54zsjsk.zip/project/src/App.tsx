import React, { useState } from 'react';
import { Hero } from './components/Hero';
import { Experience } from './components/Experience';
import { ComputerSetup } from './components/ComputerSetup';
import { IntroAnimation } from './components/IntroAnimation';

function App() {
  const [showIntro, setShowIntro] = useState(true);

  return (
    <>
      {showIntro && <IntroAnimation onComplete={() => setShowIntro(false)} />}
      <div className={`min-h-screen bg-background text-foreground transition-opacity duration-500 ${showIntro ? 'opacity-0' : 'opacity-100'}`}>
        <Hero />
        <ComputerSetup />
        <Experience />
      </div>
    </>
  );
}

export default App;